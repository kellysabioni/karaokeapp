import { Text, View } from "react-native";

export default function inicial() {
  return (
    <View>
      <Text> pagina das músicas </Text>
    </View>
  );
}
