import { Text, View } from "react-native";

export default function esqueciSenha() {
  return (
    <View>
      <Text>ESQUECEU A SENHA </Text>
    </View>
  );
}
