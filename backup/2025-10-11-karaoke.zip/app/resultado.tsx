import { Text, View } from "react-native";

export default function resultado() {
  return (
    <View>
      <Text>RESULTADO DA PESQUISA</Text>
    </View>
  );
}
