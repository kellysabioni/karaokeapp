import { Text, View } from "react-native";

export default function perfil() {
  return (
    <View>
      <Text>PERFIL</Text>
    </View>
  );
}
